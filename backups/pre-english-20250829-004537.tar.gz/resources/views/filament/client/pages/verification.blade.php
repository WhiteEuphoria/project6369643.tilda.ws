<x-filament-panels::page>
    <livewire:client.upload-document />
</x-filament-panels::page>
