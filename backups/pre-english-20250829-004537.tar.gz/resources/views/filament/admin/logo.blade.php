<div class="flex items-center justify-center py-6">
    <img
        src="{{ asset('img/logo.svg') }}"
        alt="Laravel"
        class="h-16"
    >
    
    
    
    
    
    
    
    
    
    
    
    
    
</div>
