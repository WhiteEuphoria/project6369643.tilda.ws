<?php

namespace App\Filament\Client\Pages;

use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    // Мы оставляем этот файл пустым, чтобы Filament
    // автоматически подхватывал все виджеты из папки
    // app/Filament/Client/Widgets
}
