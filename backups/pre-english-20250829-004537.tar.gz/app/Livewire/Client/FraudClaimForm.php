<?php

namespace App\Livewire\Client;

use Livewire\Component;

class FraudClaimForm extends Component
{
    public function render()
    {
        return view('livewire.client.fraud-claim-form');
    }
}
